
// con mongo db___________

const express = require("express");
const router = express.Router();

//______________________________________
const aprendizController = require("../controladores/aprendizController");

// Rutas para el modelo aprendiz
router.get("/aprendiz", aprendizController.obtenerTodosLosAprendices);
router.get("/aprendiz/:id", aprendizController.obtenerAprendizPorID);
router.post("/aprendiz", aprendizController.crearAprendiz);
router.put("/aprendiz/:id", aprendizController.actualizarAprendizPorID);
router.delete("/aprendiz/:id", aprendizController.eliminarAprendizPorID);

//______________________________________
const competenciaController = require("../controladores/competenciaController");

// Rutas para el modelo Competencia
router.get("/competencias", competenciaController.obtenerTodasLasCompetencias);
router.get("/competencias/:id", competenciaController.obtenerCompetenciaPorID);
router.post("/competencias", competenciaController.crearCompetencia);
router.put("/competencias/:id", competenciaController.actualizarCompetenciaPorID);
router.delete("/competencias/:id", competenciaController.eliminarCompetenciaPorID);
//______________________________________

const cursoController = require("../controladores/cursoController");

// Rutas para el modelo cursos
router.get("/curso", cursoController.obtenerTodosLosCursos);
router.get("/curso/:id", cursoController.obtenerCursoPorID);
router.post("/curso", cursoController.crearCurso);
router.put("/curso/:id", cursoController.actualizarCursoPorID);
router.delete("/curso/:id", cursoController.eliminarCursoPorID);
//______________________________________
const instructorController = require("../controladores/instructorController");

// Rutas para el modelo instructor
router.get("/instructor", instructorController.obtenerTodosLosInstructores);
router.get("/instructor/:id", instructorController.obtenerInstructorPorID);
router.post("/instructor", instructorController.crearInstructor);
router.put("/instructor/:id", instructorController.actualizarInstructorPorID);
router.delete("/instructor/:id", instructorController.eliminarInstructorPorID);
//______________________________________

const notasController = require("../controladores/notasController");

// Rutas para el modelo notas
router.get("/notas", notasController.obtenerTodasLasNotas);
router.get("/notas/:id", notasController.obtenerNotaPorID);
router.post("/notas", notasController.crearNota);
router.put("/notas/:id", notasController.actualizarNotaPorID);
router.delete("/notas/:id", notasController.eliminarNotaPorID); 
//______________________________________

const resultadosController = require("../controladores/resultadosController");

// Rutas para el modelo resultados
router.get("/resultados", resultadosController.obtenerTodosLosResultados);
router.get("/resultados/:id", resultadosController.obtenerResultadoPorID);
router.post("/resultados", resultadosController.crearResultado);
router.put("/resultados/:id", resultadosController.actualizarResultadoPorID);
router.delete("/resultados/:id", resultadosController.eliminarResultadoPorID); 



module.exports = router;
