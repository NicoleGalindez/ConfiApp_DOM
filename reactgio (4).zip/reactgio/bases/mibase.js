

// con mongo db _______________________________

const mongoose = require('mongoose');

// Conecta a la base de datos MongoDB
mongoose.connect('mongodb://localhost:27017/estudiantes', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  user: 'root',
  pass: '1234567890',
 // authSource: 'admin', // Si es necesario especificar una base de datos de autenticación
});

const db = mongoose.connection;

db.on('error', console.error.bind(console, 'Error de conexión a MongoDB:'));
db.once('open', () => {
  console.log('Conexión exitosa a MongoDB');
});

module.exports = db;
