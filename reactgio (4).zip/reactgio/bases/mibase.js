

// con mongo db _______________________________

import mongoose from "mongoose";
// Conecta a la base de datos MongoDB
mongoose.connect('mongodb+srv://NicoleGalindez:nicole2501@cluster0.rw5wf5u.mongodb.net/?retryWrites=true&w=majority', {
  
useNewUrlParser: true,
  useUnifiedTopology: true,
  user: 'root',
  pass: '1234567890',
 // authSource: 'admin', // Si es necesario especificar una base de datos de autenticación
});

const db = mongoose.connection;

db.on('error', console.error.bind(console, 'Error de conexión a MongoDB:'));
db.once('open', () => {
  console.log('Conexión exitosa a MongoDB');
});



export default db;
