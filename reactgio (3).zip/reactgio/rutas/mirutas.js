// import express  from "express";

// import { getAllApdz, getApdz,createApdz,updateApdz,deleteApdz } from "../controladores/micontrolador.js";

// const router=express.Router()

// router.get('/', getAllApdz)
// router.get('/:id', getApdz)
// router.post('/', createApdz)
// router.put('/', updateApdz)
// router.delete('/', deleteApdz)

// export default router;

import express from "express";

import {
  obtenerTodasLasCompetencias,
  obtenerCompetenciaPorID,
  crearCompetencia,
  actualizarCompetenciaPorID,
  eliminarCompetenciaPorID,
} from "../controladores/competenciaController.js";

import {
  obtenerTodasLasNotas,
  obtenerNotaPorID,
  crearNota,
} from "../controladores/notasController.js";

import {
  obtenerTodosLosResultados,
  obtenerResultadoPorID,
  crearResultado,
} from "../controladores/resultadosController.js";

import {
  obtenerTodosLosInstructores,
  obtenerInstructorPorID,
  crearInstructor,
} from "../controladores/instructorController.js";

// import {
//   obtenerTodosLosCursosInstru,
//   obtenerCursoInstruPorID,
//   crearCursoInstru,
// } from "../controladores/cursoInstruController.js";

import {
  obtenerTodosLosCursos,
  obtenerCursoPorID,
  crearCurso,
  actualizarCursoPorID,
  eliminarCursoPorID,
} from "../controladores/cursoController.js";

import {
  obtenerTodosLosAprendices,
  obtenerAprendizPorID,
  crearAprendiz,
  actualizarAprendizPorID,
  eliminarAprendizPorID,
} from "../controladores/aprendizController.js";

const router = express.Router();

// Rutas para el modelo Competencia
router.get("/competencias", obtenerTodasLasCompetencias);
router.get("/competencias/:id", obtenerCompetenciaPorID);
router.post("/competencias", crearCompetencia);
router.put("/competencias/:id", actualizarCompetenciaPorID);
router.delete("/competencias/:id", eliminarCompetenciaPorID);

// Rutas para el modelo Notas
router.get("/notas", obtenerTodasLasNotas);
router.get("/notas/:id", obtenerNotaPorID);
router.post("/notas", crearNota);

// Rutas para el modelo Resultados
router.get("/resultados", obtenerTodosLosResultados);
router.get("/resultados/:id", obtenerResultadoPorID);
router.post("/resultados", crearResultado);

// Rutas para el modelo Instructor
router.get("/instructores", obtenerTodosLosInstructores);
router.get("/instructores/:id", obtenerInstructorPorID);
router.post("/instructores", crearInstructor);

// // Rutas para el modelo Curso_Instru
// router.get("/cursos-instructores", obtenerTodosLosCursosInstru);
// router.get("/cursos-instructores/:id", obtenerCursoInstruPorID);
// router.post("/cursos-instructores", crearCursoInstru);

// Rutas para el modelo Curso
router.get("/cursos", obtenerTodosLosCursos);
router.get("/cursos/:id", obtenerCursoPorID);
router.post("/cursos", crearCurso);
router.put("/cursos/:id", actualizarCursoPorID);
router.delete("/cursos/:id", eliminarCursoPorID);

// Rutas para el modelo Aprendiz
router.get("/aprendices",obtenerTodosLosAprendices);
router.get("/aprendices/:id", obtenerAprendizPorID);
router.post("/aprendices", crearAprendiz);
router.put("/aprendices/:id", actualizarAprendizPorID);
router.delete("/aprendices/:id", eliminarAprendizPorID);

export default router;