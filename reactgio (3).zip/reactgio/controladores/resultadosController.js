import modelos from "../modelo/mimodelo.js"; // Asegúrate de que la ruta sea correcta

const Resultados = modelos.Resultados;

// Controlador para obtener todos los resultados
export const obtenerTodosLosResultados = async (req, res) => {
  try {
    const resultados = await Resultados.findAll();
    res.json(resultados);
  } catch (error) {
    res.status(500).json({
      message: "Error al obtener los resultados",
      error: error.message,
    });
  }
};

// Controlador para obtener un resultado por ID
export const obtenerResultadoPorID = async (req, res) => {
  const { id } = req.params;
  try {
    const resultado = await Resultados.findByPk(id);
    if (resultado) {
      res.json(resultado);
    } else {
      res
        .status(404)
        .json({ message: `No se encontró un resultado con ID ${id}` });
    }
  } catch (error) {
    res
      .status(500)
      .json({ message: "Error al obtener el resultado", error: error.message });
  }
};

// Controlador para crear un nuevo resultado
export const crearResultado = async (req, res) => {
  const nuevoResultado = req.body;
  try {
    const resultadoCreado = await Resultados.create(nuevoResultado);
    res.status(201).json(resultadoCreado);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Error al crear el resultado", error: error.message });
  }
};