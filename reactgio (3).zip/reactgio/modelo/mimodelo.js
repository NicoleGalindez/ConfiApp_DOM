
import miDb from "../bases/mibase.js";
import { DataTypes } from "sequelize";

const Curso = miDb.define(
  "Curso",
  {
    idCurso: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    nombreCurso: { type: DataTypes.STRING },
  },
  {
    timestamps: false,
    tableName: 'curso',
  }
);

const Aprendiz = miDb.define(
  "Aprendiz",
  {
    idAprendiz: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    nombreAprendiz: { type: DataTypes.STRING },
    passwordAprendiz: { type: DataTypes.STRING },
    emailAprendiz: { type: DataTypes.STRING },
    Curso_idCurso: { type: DataTypes.INTEGER },
  },
  {
    timestamps: false,
    tableName: 'aprendiz',
  }
);

const Competencia = miDb.define(
  "Competencia",
  {
    idCompetencia: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    nombreCompetencia: { type: DataTypes.STRING },
    Curso_idCurso: { type: DataTypes.INTEGER },
  },
  {
    timestamps: false,
  }
);

const Notas = miDb.define(
  "Notas",
  {
    idNotas: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    Nota1: { type: DataTypes.FLOAT },
    Nota2: { type: DataTypes.FLOAT },
    Nota3: { type: DataTypes.FLOAT },
  },
  {
    timestamps: false,
  }
);

const Resultados = miDb.define(
  "Resultados",
  {
    idResultados: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    nombreResultados: { type: DataTypes.STRING },
    Competencia_idCompetencia: { type: DataTypes.INTEGER },
    Notas_idNotas: { type: DataTypes.INTEGER },
  },
  {
    timestamps: false,
  }
);

const Instructor = miDb.define(
  "Instructor",
  {
    idInstructor: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    nombreInstructor: { type: DataTypes.STRING },
  },
  {
    timestamps: false,
    tableName: 'instructor',
  }
);

// const Curso_Instru = miDb.define(
//   "Curso_Instru",
//   {
//     Instructor_idInstructor: { type: DataTypes.INTEGER },
//     Curso_idCurso: { type: DataTypes.INTEGER },
//   },
//   {
//     timestamps: false,
//     tableName: 'Curso_Instru',
//   }
// );

const modelos ={
  Curso,
  Aprendiz,
  Competencia,
  Notas,
  Resultados,
  Instructor,
  // Curso_Instru,
};
export default modelos;
